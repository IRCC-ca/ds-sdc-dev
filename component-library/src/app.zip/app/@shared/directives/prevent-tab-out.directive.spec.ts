import { PreventTabOutDirective } from './prevent-tab-out.directive';

describe('PreventOutsideClickDirective', () => {
  it('should create an instance', () => {
    const directive = new PreventTabOutDirective();
    expect(directive).toBeTruthy();
  });
});
